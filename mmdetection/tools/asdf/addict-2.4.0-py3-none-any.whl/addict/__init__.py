from .addict import Dict
from .addict import Dict as Addict


__title__ = 'addict'
__version__ = '2.4.0'
__author__ = 'Mats Julian Olsen'
__license__ = 'MIT'
__copyright__ = 'Copyright 2014-2020 Mats Julian Olsen'
__all__ = ['Dict']
